import java.util.ArrayList;

public class C7_1 {
	public static void main(String[] args){
		ArrayList<String> list = new ArrayList<String>();
		list.add("abc");
		list.add("def");
		list.add("ghi");
		print(list);
	}
	public static void print(ArrayList<String> list){
		int size = list.size();
		for(int i = 0; i < size; i++){
			System.out.print(list.get(i));
			if(i == size - 1){
				break;
			}
			System.out.print(",");
		}
	}
}
