
public class C1_1 {
	public static void main(String[] args){
		Instructor inst1 = new Instructor("001");
		inst1.setName("kohama");
		
	}
}
