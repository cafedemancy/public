
public interface Employee extends User{
	public int getPostNumber();
	public void setPostNumber(int number);
}
