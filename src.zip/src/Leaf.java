
public class Leaf implements Node{
	private String name;
	
	public Leaf(String name){
		this.name = name;
	}
	public String getName(){
		return this.name;
	}
}
