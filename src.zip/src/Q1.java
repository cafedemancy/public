
public class Q1 {
	public static void main(String[] args){
		Spray spray = new Spray("き");
		spray.setLeft(new Spray("よ"));
		spray.setRight(new Spray("は"));
	}
}
