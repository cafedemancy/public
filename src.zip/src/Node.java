
public interface Node {
	public String getName();
}
