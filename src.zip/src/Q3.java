
public class Q3 {
	public static void main(String[] args){
		Spray spray = new Spray("あ");
		Spray left = new Spray("か");
		Spray right = new Spray("さ");
		
		spray.setLeft(left);
		spray.setRight(right);
		
		left.setLeft(new Leaf("た"));
		left.setRight(new Leaf("な"));
		
		right.setLeft(new Leaf("は"));
		right.setRight(new Leaf("ま"));
		
	}
}
