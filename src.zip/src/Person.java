
public interface Person {
	public String getName();
	public String getId();
}
