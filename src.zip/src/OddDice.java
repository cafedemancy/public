import java.util.Random;

public class OddDice implements Castable{
	protected Random random = new Random();
	protected int value = 1;
	
	public OddDice(){
		
	}
	public void cast(){
		
	}
	public int getValue(){
		return 0;
	}
}
