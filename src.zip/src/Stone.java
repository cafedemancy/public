
public class Stone {

}
