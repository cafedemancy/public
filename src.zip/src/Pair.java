
public class Pair {
	private Person first;
	private Person second;
	public Pair(){
		
	}
	public void setFirst(Person first){
		this.first = first;
	}
	public void setSecond(Person second){
		this.second = second;
	}
	public Person getFirst(){
		return this.first;
	}
	public Person getSecond(){
		return this.second;
	}
}
