
public class E5_0 {
	public static void main(String[] args){
		Dice dice = new Dice();
		System.out.println(dice.getValue());
		dice.cast();
		System.out.println(dice.getValue());
	}
}
