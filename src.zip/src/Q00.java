
public class Q00 {

}
