import java.util.Random;

public class EvenDice implements Castable{
	protected Random random = new Random();
	protected int value = 2;
	
	public EvenDice(){
		
	}
	public void cast(){
		
	}
	public int getValue(){
		return 0;
	}
}
