
public interface Castable {
	public void cast();
	public int getValue();
}
