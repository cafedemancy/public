
public interface Visitor {
	public void visit(User User);
}
