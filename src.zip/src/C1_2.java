
public class C1_2 {
	public static void main(String[] args){
		Assistant p1 = new Assistant();
		p1.setName("takano");
		p1.setId("002");
		System.out.print(p1.getName() + " ");
		System.out.println(p1.getId());
	}
}
